import type { EventSubscription } from 'react-native';
export interface LocationEvent {
    latitude: number;
    longitude: number;
    accuracy: number;
    timestamp: string;
    is_mock: boolean;
}
export interface MotionEvent {
    activity: 'STILL' | 'WALKING' | 'RUNNING' | 'ON_BICYCLE' | 'IN_VEHICLE' | 'UNKNOWN';
    isMoving: boolean;
    state: 'MOVING' | 'STATIONARY';
}
export interface ErrorEvent {
    error: string;
    message: string;
}
export declare const startForegroundService: (title: string, body: string, id: number) => Promise<boolean>;
export declare const stopForegroundService: () => Promise<boolean>;
export declare const updateServiceNotification: (title: string, body: string) => Promise<boolean>;
export declare const startMotionDetector: (confidence?: number) => Promise<boolean>;
export declare const stopMotionDetector: () => Promise<boolean>;
export declare const setLocationUpdateInterval: (ms: number) => Promise<void>;
export declare const fireGeofenceAlert: (type: "IN" | "OUT", userName: string) => Promise<boolean>;
export declare const fireGenericAlert: (title: string, body: string, id: number) => Promise<boolean>;
export declare const cancelGenericAlert: (id: number) => Promise<boolean>;
export declare const registerGpsListener: () => Promise<boolean>;
export declare const addGpsStatusListener: (cb: (event: {
    enabled: boolean;
}) => void) => EventSubscription;
export declare const addMotionListener: (cb: (event: MotionEvent) => void) => EventSubscription;
export declare const addLocationLogListener: (cb: (event: LocationEvent) => void) => EventSubscription;
export declare const addLocationErrorListener: (cb: (event: ErrorEvent) => void) => EventSubscription;
declare const _default: {
    startForegroundService: (title: string, body: string, id: number) => Promise<boolean>;
    stopForegroundService: () => Promise<boolean>;
    updateServiceNotification: (title: string, body: string) => Promise<boolean>;
    startMotionDetector: (confidence?: number) => Promise<boolean>;
    stopMotionDetector: () => Promise<boolean>;
    setLocationUpdateInterval: (ms: number) => Promise<void>;
    fireGeofenceAlert: (type: "IN" | "OUT", userName: string) => Promise<boolean>;
    fireGenericAlert: (title: string, body: string, id: number) => Promise<boolean>;
    cancelGenericAlert: (id: number) => Promise<boolean>;
    registerGpsListener: () => Promise<boolean>;
    addGpsStatusListener: (cb: (event: {
        enabled: boolean;
    }) => void) => EventSubscription;
    addMotionListener: (cb: (event: MotionEvent) => void) => EventSubscription;
    addLocationLogListener: (cb: (event: LocationEvent) => void) => EventSubscription;
    addLocationErrorListener: (cb: (event: ErrorEvent) => void) => EventSubscription;
};
export default _default;
//# sourceMappingURL=index.d.ts.map